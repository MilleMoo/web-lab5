#include<stdio.h>

int main(){
int i,k;
char *name[3];
printf("Enter name :");
scanf("%d",&k);
}
