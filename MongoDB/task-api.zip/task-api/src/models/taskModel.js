const mongoose = require("mongoose");

const taskSchema = new mongoose.Schema(
    {
        title: {
            type: String,
            required: true,
            trim: true
        },
        priority: {
            type: String,
            enum: ["High", "Medium", "Low"],
            required: true,
        },
        DateNow: {
            type: Date,
            default: Date.now,
        },
        dueDate: {
            type: Date,
            required: true,
        },
        isCompleted: {
            type: Boolean,
            default: false
        }
    },
    {
        timestamp: true
    }
)

const Task = mongoose.model("Task", taskSchema);
module.exports = Task