const Task = require("../models/taskModel");

exports.createTask = async (req, res) => {
    try{
        const task = new Task(req.body);
        await task.save();
        res.status(201).send(task);
    } catch (err){
        res.status(400).send(err);
    }
}

exports.getAllTasks = async (req, res) => {
    try{
        const { completed, priority, title, dueDate, sortBy } = req.query;
        const queryObject = {};

        if (completed) {
            queryObject.isCompleted = completed === 'true';
        }

        if (!completed) {
            queryObject.isCompleted = completed === 'false';
        }


        if (priority) {
            queryObject.priority = priority;
        }

        if (title) {
            queryObject.title = { $regex: title, $options: 'i' };
        }

        let query = Task.find(queryObject);

        if (sortBy) {
            const [sortField, sortOrder] = sortBy.split(':');
            query = query.sort({ [sortField]: sortOrder === 'desc' ? -1 : 1 });
        } else {
            query = query.sort({ createdAt: -1 });
        }
        

        if (dueDate) {
            queryObject.dueDate = {};
            if (dueDate.gte) {
                queryObject.dueDate.$gte = new Date(dueDate.gte);
            }
            if (dueDate.lte) {
                queryObject.dueDate.$lte = new Date(dueDate.lte);
            }
        }

        const tasks = await query;
        res.status(200).send(tasks);
    }catch(err){
        res.status(500).send(err);
    }
}


exports.getTaskById = async (req, res) => {
    try {
        const task = await Task.findById(req.params.id);
        if (!task){
            return res.status(404).send();
        }
        res.status(200).send(task);
    }catch(err){
        res.status(500).console.log(err);
    }
}

exports.updateTask = async (req, res) => {
    try {
        const task = await Task.findByIdAndUpdate(req.params.id, req.body, {
            new: true,
            runValidators: true
        });
    }catch(err){
        res.status(500).console.log(err);
    }
}

exports.deleteTask = async (req, res) => {
    const task = await Task.findByIdAndDelete(req.params.id);
    try {
        if (!task){
            return res.status(404).send();
        }
        res.status(200).send(task);
    }catch (err){
        res.status(500).send(err);
    }
}